import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth, useLogout } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Copy, Link, WandSparkles, Plus, Share, Clock, Shield, BarChart3, Check, X, Crown, LogOut, User, Upload } from "lucide-react";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useLocation } from "wouter";

interface LinkResponse {
  id: string;
  shortCode: string;
  originalUrl: string;
  shortUrl: string;
  isUsed: boolean;
  createdAt: string;
}

// AdSense component
const AdSenseAd = ({ user }: { user?: any }) => {
  if (user?.isPremium) return null; // Hide ads for premium users
  
  return (
    <div className="bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center my-6">
      <div className="text-gray-500 dark:text-gray-400 text-sm mb-2">Advertisement</div>
      <div className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded p-8 text-gray-400 dark:text-gray-300">
        {/* This would be replaced with actual AdSense code */}
        <p>AdSense Ad Placeholder</p>
        <p className="text-xs mt-2">Upgrade to Premium to remove ads</p>
      </div>
    </div>
  );
};

export default function Home() {
  const [url, setUrl] = useState("");
  const [createdLink, setCreatedLink] = useState<LinkResponse | null>(null);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const logoutMutation = useLogout();

  // Check for URL parameters on load
  const urlParams = new URLSearchParams(window.location.search);
  const error = urlParams.get('error');
  const errorCode = urlParams.get('code');

  const createLinkMutation = useMutation({
    mutationFn: async (originalUrl: string) => {
      const response = await apiRequest("POST", "/api/links", { originalUrl });
      return response.json();
    },
    onSuccess: (data: LinkResponse) => {
      setCreatedLink(data);
      toast({
        title: "Link Created!",
        description: "Your one-time link is ready to share.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create link. Please check your URL and try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      toast({
        title: "Error",
        description: "Please enter a URL",
        variant: "destructive",
      });
      return;
    }

    try {
      new URL(url);
      createLinkMutation.mutate(url);
    } catch {
      toast({
        title: "Error",
        description: "Please enter a valid URL (must include http:// or https://)",
        variant: "destructive",
      });
    }
  };

  const handleCopyToClipboard = async () => {
    if (!createdLink) return;
    
    try {
      await navigator.clipboard.writeText(createdLink.shortUrl);
      toast({
        title: "Copied!",
        description: "Link copied to clipboard",
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleCreateAnother = () => {
    setUrl("");
    setCreatedLink(null);
    // Clear URL parameters
    window.history.replaceState({}, document.title, window.location.pathname);
  };

  const handleShare = async () => {
    if (!createdLink) return;

    if (navigator.share) {
      try {
        await navigator.share({
          title: "One-Time Link",
          text: "Check out this one-time link:",
          url: createdLink.shortUrl,
        });
      } catch (err) {
        // User cancelled or error occurred, fallback to copy
        handleCopyToClipboard();
      }
    } else {
      // Fallback to copy
      handleCopyToClipboard();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 font-inter antialiased">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-purple-600 rounded-lg flex items-center justify-center">
                <Link className="text-white" size={16} />
              </div>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">LinkOnce</h1>
            </div>
            <nav className="flex items-center space-x-4">
              <ThemeToggle />
              {isAuthenticated ? (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={() => setLocation("/files")}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    <Upload className="mr-1" size={16} />
                    Files
                  </Button>
                  {user?.isPremium ? (
                    <Badge className="bg-gradient-to-r from-primary to-purple-600 text-white">
                      <Crown className="mr-1" size={12} />
                      Premium
                    </Badge>
                  ) : (
                    <Button 
                      variant="outline"
                      onClick={() => setLocation("/premium")}
                      className="border-primary text-primary hover:bg-primary hover:text-white"
                    >
                      <Crown className="mr-1" size={14} />
                      Upgrade
                    </Button>
                  )}
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center space-x-1 text-gray-600">
                      <User size={16} />
                      <span className="text-sm">{user?.username}</span>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => logoutMutation.mutate()}
                      className="text-gray-600 hover:text-gray-900"
                    >
                      <LogOut size={16} />
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={() => setLocation("/login")}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    Sign In
                  </Button>
                  <Button 
                    onClick={() => setLocation("/premium")}
                    className="bg-gradient-to-r from-primary to-purple-600 text-white"
                  >
                    <Crown className="mr-1" size={14} />
                    Premium
                  </Button>
                </>
              )}
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32">
        {/* Abstract tech background decoration */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-800 dark:via-gray-900 dark:to-gray-800"></div>
        <div className="absolute top-10 right-10 w-32 h-32 bg-blue-100 rounded-full opacity-20 blur-xl"></div>
        <div className="absolute bottom-20 left-10 w-48 h-48 bg-purple-100 rounded-full opacity-20 blur-xl"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
            Create{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-600">
              One-Time
            </span>{" "}
            Short Links
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto leading-relaxed">
            Transform long URLs into secure, one-time use links that automatically expire after a single click. Perfect for sharing sensitive or time-sensitive content.
          </p>
          
          {/* Ad for non-premium users */}
          <AdSenseAd user={user} />

          {/* Error Messages */}
          {error === 'expired' && (
            <div className="max-w-2xl mx-auto mb-8">
              <Card className="border-red-200 bg-red-50">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <X className="text-red-600" size={24} />
                    </div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-2">Link Expired</h3>
                    <p className="text-gray-600 mb-6">This one-time link has already been used and is no longer valid.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {error === 'not-found' && (
            <div className="max-w-2xl mx-auto mb-8">
              <Card className="border-red-200 bg-red-50">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <X className="text-red-600" size={24} />
                    </div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-2">Link Not Found</h3>
                    <p className="text-gray-600 mb-6">The link you're looking for doesn't exist or has been removed.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* URL Input Form */}
          {!createdLink ? (
            <div className="max-w-2xl mx-auto mb-16">
              <Card className="shadow-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <Label htmlFor="url-input" className="sr-only">Enter your long URL</Label>
                      <div className="relative">
                        <Input
                          id="url-input"
                          type="url"
                          value={url}
                          onChange={(e) => setUrl(e.target.value)}
                          placeholder="Paste your long URL here... (e.g., https://example.com/very/long/path)"
                          className="w-full px-6 py-4 text-lg border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent font-mono bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center pr-4">
                          <Link className="text-gray-400 dark:text-gray-500" size={20} />
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      type="submit"
                      disabled={createLinkMutation.isPending}
                      className="w-full bg-gradient-to-r from-primary to-blue-600 text-white font-semibold py-4 px-8 rounded-xl hover:from-blue-600 hover:to-blue-700 focus:ring-4 focus:ring-blue-200 transition-all duration-200 transform hover:-translate-y-0.5"
                    >
                      {createLinkMutation.isPending ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Generating...
                        </>
                      ) : (
                        <>
                          <WandSparkles className="mr-2" size={20} />
                          Create One-Time Link
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Results Section */
            <div className="max-w-2xl mx-auto mb-16">
              <Card className="shadow-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="text-green-600" size={24} />
                    </div>
                    <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">Your One-Time Link is Ready!</h3>
                    <p className="text-gray-600 dark:text-gray-300">This link will expire after its first use</p>
                  </div>

                  <div className="space-y-4">
                    {/* Generated Short URL */}
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 border border-gray-200 dark:border-gray-600">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Your One-Time Link</Label>
                          <div className="font-mono text-lg text-primary truncate">
                            {createdLink.shortUrl}
                          </div>
                        </div>
                        <Button 
                          onClick={handleCopyToClipboard}
                          className="ml-4 bg-primary text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                        >
                          <Copy className="mr-1" size={16} />
                          Copy
                        </Button>
                      </div>
                    </div>

                    {/* Link Status */}
                    <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-xl">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                        <span className="text-green-800 font-medium">Active</span>
                      </div>
                      <span className="text-green-600 text-sm">Ready for use (1 click remaining)</span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <Button 
                        onClick={handleShare}
                        variant="outline"
                        className="flex-1 bg-gray-100 text-gray-700 font-medium py-3 px-4 rounded-xl hover:bg-gray-200 transition-colors"
                      >
                        <Share className="mr-2" size={16} />
                        Share
                      </Button>
                      <Button 
                        onClick={handleCreateAnother}
                        className="flex-1 bg-blue-100 text-blue-700 font-medium py-3 px-4 rounded-xl hover:bg-blue-200 transition-colors"
                      >
                        <Plus className="mr-2" size={16} />
                        Create Another
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Why Choose One-Time Links?</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">Perfect for sharing sensitive content, exclusive offers, or time-sensitive information</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Shield className="text-primary" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Enhanced Security</h3>
              <p className="text-gray-600">Links automatically expire after one use, preventing unauthorized access to sensitive content.</p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Clock className="text-accent" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Time-Sensitive Sharing</h3>
              <p className="text-gray-600">Perfect for sharing exclusive offers, event tickets, or time-limited content that should only be accessed once.</p>
            </div>

            <div className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <BarChart3 className="text-purple-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Usage Tracking</h3>
              <p className="text-gray-600">Know exactly when your link was used with clear status indicators and expiration notifications.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">Simple, secure, and automatic - no setup required</p>
          </div>

          <div className="relative mb-16">
            <div className="rounded-2xl shadow-lg w-full h-64 bg-gradient-to-r from-blue-400 to-purple-500 flex items-center justify-center">
              <div className="text-center text-white">
                <div className="grid grid-cols-3 gap-8 max-w-md mx-auto">
                  <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center">
                    <Link size={24} />
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center">
                    <WandSparkles size={24} />
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center">
                    <Shield size={24} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="relative">
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-semibold mr-3">1</div>
                <h3 className="text-xl font-semibold text-gray-900">Paste Your URL</h3>
              </div>
              <p className="text-gray-600 ml-11">Simply paste your long URL into our secure input field. We support any valid web address.</p>
            </div>

            <div className="relative">
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-semibold mr-3">2</div>
                <h3 className="text-xl font-semibold text-gray-900">Get Short Link</h3>
              </div>
              <p className="text-gray-600 ml-11">Our system generates a unique, secure short link that's ready to share immediately.</p>
            </div>

            <div className="relative">
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-semibold mr-3">3</div>
                <h3 className="text-xl font-semibold text-gray-900">Auto-Expiration</h3>
              </div>
              <p className="text-gray-600 ml-11">After the first click, the link automatically expires and becomes inaccessible.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-6">
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">What happens after someone clicks my one-time link?</h3>
              <p className="text-gray-600">Once your link is clicked, the visitor is redirected to your original URL and the short link immediately expires. Any subsequent attempts to access the link will show an expiration message.</p>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Is there a time limit on unused links?</h3>
              <p className="text-gray-600">One-time links remain active indefinitely until they're used. They only expire after being clicked once, not after a specific time period.</p>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Can I track when my link was used?</h3>
              <p className="text-gray-600">Yes! Our interface shows you the current status of your link - whether it's active and ready to use, or if it has already been clicked and expired.</p>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">What types of URLs can I shorten?</h3>
              <p className="text-gray-600">You can shorten any valid web URL, including websites, documents, images, videos, and other online resources. We automatically validate URLs to ensure they're properly formatted.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-purple-600 rounded-lg flex items-center justify-center">
                <Link className="text-white" size={16} />
              </div>
              <span className="text-xl font-semibold">LinkOnce</span>
            </div>
            
            <div className="flex items-center space-x-6 text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Contact</a>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 LinkOnce. All rights reserved. Secure one-time URL shortening service.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
