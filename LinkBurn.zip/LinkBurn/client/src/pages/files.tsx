import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, File, Image, FileText, Trash2, Crown, AlertTriangle, Share2, Copy, Clock } from "lucide-react";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useLocation } from "wouter";

interface FileData {
  id: string;
  filename: string;
  originalName: string;
  size: number;
  url: string;
  isShared: boolean;
  shortCode: string | null;
  shareUrl: string | null;
  isOneTime: boolean;
  isUsed: boolean;
  createdAt: string;
}

export default function FilesPage() {
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: files = [], isLoading } = useQuery<FileData[]>({
    queryKey: ['/api/files'],
    enabled: isAuthenticated,
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/files/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File uploaded!",
        description: "Your file has been uploaded successfully.",
      });
      setUploadProgress(0);
    },
    onError: (error: any) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setUploadProgress(0);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const response = await apiRequest("DELETE", `/api/files/${fileId}`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File deleted",
        description: "The file has been removed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const shareMutation = useMutation({
    mutationFn: async ({ fileId, isOneTime }: { fileId: string; isOneTime: boolean }) => {
      const response = await apiRequest("POST", `/api/files/${fileId}/share`, {
        isOneTime,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "Share link created",
        description: "Your file is now shareable!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Share failed",
        description: error.message || "Failed to create share link",
        variant: "destructive",
      });
    },
  });

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Share link copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const handleShare = (fileId: string, isOneTime: boolean) => {
    shareMutation.mutate({ fileId, isOneTime });
  };

  const handleFileUpload = (file: File) => {
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }

    const maxSize = user?.isPremium ? 500 * 1024 * 1024 : 2 * 1024 * 1024;
    if (file.size > maxSize) {
      toast({
        title: "File too large",
        description: `${user?.isPremium ? 'Premium' : 'Free'} users can upload files up to ${user?.isPremium ? '500MB' : '2MB'}.`,
        variant: "destructive",
      });
      return;
    }

    setUploadProgress(10);
    uploadMutation.mutate(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return <Image size={20} />;
    if (mimeType.includes('pdf') || mimeType.includes('document')) return <FileText size={20} />;
    return <File size={20} />;
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <Upload className="mx-auto mb-4 text-gray-400" size={48} />
            <h2 className="text-xl font-semibold mb-2">Sign in required</h2>
            <p className="text-gray-600 mb-4">You need to sign in to upload and manage files.</p>
            <Button onClick={() => setLocation("/login")}>Sign In</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">File Manager</h1>
            <p className="text-gray-600 dark:text-gray-300">Upload and manage your files</p>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            {user?.isPremium ? (
              <Badge className="bg-gradient-to-r from-primary to-purple-600 text-white">
                <Crown className="mr-1" size={12} />
                Premium
              </Badge>
            ) : (
              <Button
                variant="outline"
                onClick={() => setLocation("/premium")}
                className="border-primary text-primary hover:bg-primary hover:text-white"
              >
                <Crown className="mr-2" size={16} />
                Upgrade
              </Button>
            )}
            <Button onClick={() => setLocation("/")} variant="ghost">
              Back to Home
            </Button>
          </div>
        </div>

        {/* Upload Area */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Upload Files</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive
                  ? "border-primary bg-primary/5"
                  : "border-gray-300 hover:border-gray-400"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="mx-auto mb-4 text-gray-400" size={48} />
              <h3 className="text-lg font-semibold mb-2">Drop files here or click to browse</h3>
              <p className="text-gray-600 mb-4">
                {user?.isPremium ? 'Upload files up to 500MB' : 'Upload files up to 2MB'}
              </p>
              
              {!user?.isPremium && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 text-sm">
                  <AlertTriangle className="inline mr-2" size={16} />
                  <span className="text-blue-800">
                    Upgrade to Premium for 500MB uploads! 
                    <button 
                      onClick={() => setLocation("/premium")}
                      className="ml-1 font-medium underline"
                    >
                      Learn more
                    </button>
                  </span>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.csv"
              />
              
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadMutation.isPending}
                className="bg-primary hover:bg-primary/90"
              >
                {uploadMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Uploading...
                  </>
                ) : (
                  "Choose Files"
                )}
              </Button>
              
              {uploadProgress > 0 && uploadProgress < 100 && (
                <div className="mt-4">
                  <Progress value={uploadProgress} className="w-full" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Files List */}
        <Card>
          <CardHeader>
            <CardTitle>Your Files</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-gray-600 mt-2">Loading files...</p>
              </div>
            ) : files.length === 0 ? (
              <div className="text-center py-8">
                <File className="mx-auto mb-4 text-gray-400" size={48} />
                <p className="text-gray-600">No files uploaded yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {files.map((file: FileData) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="text-gray-400">
                        {getFileIcon(file.originalName)}
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{file.originalName}</h4>
                        <p className="text-sm text-gray-600">
                          {formatFileSize(file.size)} • {new Date(file.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(file.url, '_blank')}
                      >
                        View
                      </Button>
                      {file.isShared ? (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <Share2 size={16} />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Share Link</DialogTitle>
                              <DialogDescription>
                                Your file is shared. Copy the link below.
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="flex items-center space-x-2">
                                <Input
                                  value={file.shareUrl || ''}
                                  readOnly
                                  className="flex-1"
                                />
                                <Button
                                  onClick={() => copyToClipboard(file.shareUrl!)}
                                  size="sm"
                                >
                                  <Copy size={16} />
                                </Button>
                              </div>
                              <div className="flex items-center space-x-2 text-sm text-gray-600">
                                {file.isOneTime ? (
                                  <>
                                    <Clock size={16} />
                                    <span>
                                      One-time link {file.isUsed ? '(Used)' : '(Available)'}
                                    </span>
                                  </>
                                ) : (
                                  <span>Permanent share link</span>
                                )}
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      ) : (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <Share2 size={16} />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Create Share Link</DialogTitle>
                              <DialogDescription>
                                Create a shareable link for this file.
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="flex items-center space-x-2">
                                <Switch
                                  id={`one-time-${file.id}`}
                                />
                                <Label htmlFor={`one-time-${file.id}`} className="text-sm">
                                  One-time link (expires after first access)
                                </Label>
                              </div>
                              <Button
                                onClick={() => {
                                  const switchEl = document.getElementById(`one-time-${file.id}`) as HTMLInputElement;
                                  const isOneTime = switchEl?.checked || false;
                                  handleShare(file.id, isOneTime);
                                }}
                                disabled={shareMutation.isPending}
                                className="w-full"
                              >
                                Create Share Link
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteMutation.mutate(file.id)}
                        disabled={deleteMutation.isPending}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}