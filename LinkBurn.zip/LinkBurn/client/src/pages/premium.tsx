import { useState } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Upload, Shield, Zap } from "lucide-react";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useLocation } from "wouter";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = ({ clientSecret }: { clientSecret: string }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin + "/premium-success",
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    }
    
    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full bg-gradient-to-r from-primary to-purple-600"
      >
        {isProcessing ? (
          <>
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            Processing...
          </>
        ) : (
          <>
            <Crown className="mr-2" size={16} />
            Subscribe for $5/month
          </>
        )}
      </Button>
    </form>
  );
};

export default function PremiumPage() {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const startSubscription = async () => {
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/create-subscription", {});
      const data = await response.json();
      setClientSecret(data.clientSecret);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to start subscription",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  if (user?.isPremium) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-20">
        <div className="absolute top-4 right-4">
          <ThemeToggle />
        </div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-gradient-to-br from-primary to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Crown className="text-white" size={32} />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">You're Premium!</h1>
            <p className="text-xl text-gray-600">Enjoy all premium features and ad-free experience</p>
            <Badge className="mt-4 bg-gradient-to-r from-primary to-purple-600 text-white">
              Premium Member
            </Badge>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Upload className="text-primary mr-3" size={24} />
                  <h3 className="text-lg font-semibold">Large File Uploads</h3>
                </div>
                <p className="text-gray-600">Upload files up to 500MB instead of the 2MB limit for free users.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center mb-4">
                  <Shield className="text-primary mr-3" size={24} />
                  <h3 className="text-lg font-semibold">Ad-Free Experience</h3>
                </div>
                <p className="text-gray-600">Enjoy LinkOnce without any distracting advertisements.</p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button onClick={() => setLocation("/")} size="lg">
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-20">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Upgrade to{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-600">
              Premium
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8">Unlock powerful features and enjoy an ad-free experience</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Features */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Premium Benefits</h2>
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-4 mt-1">
                  <Check className="text-green-600" size={16} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Large File Uploads</h3>
                  <p className="text-gray-600">Upload images and documents up to 500MB (vs 2MB for free users)</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-4 mt-1">
                  <Check className="text-green-600" size={16} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Ad-Free Experience</h3>
                  <p className="text-gray-600">Enjoy LinkOnce without any advertisements or distractions</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-4 mt-1">
                  <Check className="text-green-600" size={16} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Priority Support</h3>
                  <p className="text-gray-600">Get priority customer support and faster response times</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-4 mt-1">
                  <Check className="text-green-600" size={16} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Advanced Analytics</h3>
                  <p className="text-gray-600">Track detailed usage statistics for your links and files</p>
                </div>
              </div>
            </div>
          </div>

          {/* Subscription */}
          <div>
            <Card className="shadow-lg">
              <CardHeader>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Crown className="text-white" size={24} />
                  </div>
                  <CardTitle className="text-2xl mb-2">Premium Plan</CardTitle>
                  <div className="text-4xl font-bold text-gray-900 mb-1">
                    $5<span className="text-lg font-normal text-gray-600">/month</span>
                  </div>
                  <p className="text-gray-600">Cancel anytime</p>
                </div>
              </CardHeader>
              <CardContent>
                {!clientSecret ? (
                  <div className="space-y-4">
                    {!isAuthenticated && (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                        <p className="text-blue-800 text-sm">
                          You need to <button 
                            onClick={() => setLocation("/login")}
                            className="font-medium underline"
                          >
                            sign in
                          </button> to subscribe to premium.
                        </p>
                      </div>
                    )}
                    
                    <Button 
                      onClick={startSubscription}
                      disabled={isLoading || !isAuthenticated}
                      className="w-full bg-gradient-to-r from-primary to-purple-600"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Setting up...
                        </>
                      ) : (
                        <>
                          <Zap className="mr-2" size={16} />
                          Start Premium Subscription
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <Elements stripe={stripePromise} options={{ clientSecret }}>
                    <SubscribeForm clientSecret={clientSecret} />
                  </Elements>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center mt-12">
          <Button 
            variant="ghost" 
            onClick={() => setLocation("/")}
          >
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
}