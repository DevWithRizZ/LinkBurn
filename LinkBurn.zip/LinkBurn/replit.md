# Overview

This is a URL shortener application built with a React frontend and Express backend. The app creates one-time use short links that redirect to the original URL and become invalid after being accessed once. It features a modern UI built with shadcn/ui components and uses PostgreSQL with Drizzle ORM for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives with Tailwind CSS styling
- **Routing**: Wouter for client-side routing with pages for home, redirect handling, and 404
- **State Management**: TanStack Query (React Query) for server state management and API caching
- **Form Handling**: React Hook Form with Zod validation for URL input validation
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **API Design**: RESTful endpoints for link creation (`POST /api/links`) and retrieval (`GET /api/links/:shortCode`)
- **Middleware**: Custom logging middleware for API request tracking, JSON body parsing, and error handling
- **Development Setup**: Vite integration for hot module replacement in development mode

## Data Layer
- **Database**: PostgreSQL configured through environment variables
- **ORM**: Drizzle ORM with TypeScript-first schema definition
- **Schema**: Two main entities - `users` (for future authentication) and `links` (storing short codes, original URLs, and usage status)
- **Migrations**: Drizzle Kit for database schema migrations stored in `/migrations` directory
- **Storage Interface**: Abstracted storage layer with in-memory fallback implementation for development

## Key Features
- **One-time Links**: Short links become invalid after first use via `isUsed` flag and `usedAt` timestamp
- **Short Code Generation**: Automatic generation of unique short codes for each URL
- **URL Validation**: Client and server-side validation ensuring only valid URLs are accepted
- **Usage Tracking**: Timestamps for link creation and first usage
- **Redirect Handling**: Server-side redirects for `/s/:shortCode` pattern with client-side fallback

## External Dependencies

- **Database**: PostgreSQL via `@neondatabase/serverless` driver for serverless-compatible connections
- **UI Components**: Radix UI primitives for accessible component foundation
- **Validation**: Zod for runtime type validation and schema parsing
- **Development Tools**: 
  - Replit integration via cartographer plugin and development banner
  - ESBuild for production server bundling
  - PostCSS with Autoprefixer for CSS processing

The application uses environment variables for database configuration and supports both development and production deployment scenarios through different build processes.