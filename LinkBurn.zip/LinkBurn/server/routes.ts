import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertLinkSchema, insertUserSchema, loginUserSchema, insertFileSchema } from "@shared/schema";
import { hashPassword, verifyPassword, getSession, requireAuth, optionalAuth } from "./auth";
import { z } from "zod";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-07-30.basil",
});

// Configure multer for file uploads
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB max (will be controlled by user tier)
  },
  fileFilter: (req, file, cb) => {
    // Allow images and documents
    const allowedTypes = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain', 'text/csv'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('File type not allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(getSession());
  
  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    // Check if user has access to this file
    // For now, serve all files (could add auth check here)
    next();
  });
  app.use('/uploads', express.static(uploadDir));
  // Auth Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Hash password and create user
      const hashedPassword = await hashPassword(validatedData.password);
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });
      
      // Set session
      req.session.userId = user.id;
      
      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        isPremium: user.isPremium,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid data provided",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create account" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginUserSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(validatedData.username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const isValidPassword = await verifyPassword(validatedData.password, user.password);
      
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Set session
      req.session.userId = user.id;
      
      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        isPremium: user.isPremium,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid data provided",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to login" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  
  app.get("/api/auth/me", async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        isPremium: user.isPremium,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user info" });
    }
  });

  // Create a new short link
  app.post("/api/links", optionalAuth, async (req, res) => {
    try {
      const validatedData = insertLinkSchema.parse(req.body);
      const userId = req.session?.userId;
      const link = await storage.createLink(validatedData, userId);
      
      const shortUrl = `${req.protocol}://${req.get('host')}/s/${link.shortCode}`;
      
      res.json({
        id: link.id,
        shortCode: link.shortCode,
        originalUrl: link.originalUrl,
        shortUrl,
        isUsed: link.isUsed,
        createdAt: link.createdAt,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid URL provided",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create short link" });
    }
  });

  // Get link status
  app.get("/api/links/:shortCode", async (req, res) => {
    try {
      const link = await storage.getLinkByShortCode(req.params.shortCode);
      
      if (!link) {
        return res.status(404).json({ message: "Link not found" });
      }

      const shortUrl = `${req.protocol}://${req.get('host')}/s/${link.shortCode}`;
      
      res.json({
        id: link.id,
        shortCode: link.shortCode,
        originalUrl: link.originalUrl,
        shortUrl,
        isUsed: link.isUsed,
        createdAt: link.createdAt,
        usedAt: link.usedAt,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve link" });
    }
  });

  // File upload routes
  app.post("/api/files/upload", requireAuth, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check file size limits based on user tier
      const maxSize = user.isPremium ? 500 * 1024 * 1024 : 2 * 1024 * 1024; // 500MB for premium, 2MB for free
      if (req.file.size > maxSize) {
        // Delete uploaded file
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ 
          message: `File too large. ${user.isPremium ? 'Premium' : 'Free'} users can upload files up to ${user.isPremium ? '500MB' : '2MB'}.` 
        });
      }
      
      const fileData = {
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        path: req.file.path,
      };
      
      const file = await storage.createFile(fileData, user.id);
      
      res.json({
        id: file.id,
        filename: file.filename,
        originalName: file.originalName,
        size: file.size,
        url: `/uploads/${file.filename}`,
        createdAt: file.createdAt,
      });
    } catch (error) {
      console.error('File upload error:', error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });
  
  app.get("/api/files", requireAuth, async (req, res) => {
    try {
      const files = await storage.getFilesByUser(req.session.userId!);
      res.json(files.map(file => ({
        id: file.id,
        filename: file.filename,
        originalName: file.originalName,
        size: file.size,
        url: `/uploads/${file.filename}`,
        isShared: file.isShared,
        shortCode: file.shortCode,
        shareUrl: file.shortCode ? `${req.protocol}://${req.get('host')}/f/${file.shortCode}` : null,
        isOneTime: file.isOneTime,
        isUsed: file.isUsed,
        createdAt: file.createdAt,
      })));
    } catch (error) {
      res.status(500).json({ message: "Failed to get files" });
    }
  });
  
  app.delete("/api/files/:id", requireAuth, async (req, res) => {
    try {
      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      if (file.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Delete file from filesystem
      if (fs.existsSync(file.path)) {
        fs.unlinkSync(file.path);
      }
      
      const deleted = await storage.deleteFile(req.params.id);
      if (deleted) {
        res.json({ message: "File deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete file" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Create shareable link for file
  app.post('/api/files/:id/share', requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { isOneTime } = req.body;
      
      const file = await storage.getFile(id);
      if (!file || file.userId !== req.session.userId) {
        return res.status(404).json({ message: 'File not found' });
      }
      
      const sharedFile = await storage.createFileShare(id, isOneTime || false);
      if (!sharedFile) {
        return res.status(500).json({ message: 'Failed to create shareable link' });
      }
      
      res.json({
        shortCode: sharedFile.shortCode,
        shareUrl: `${req.protocol}://${req.get('host')}/f/${sharedFile.shortCode}`,
        isOneTime: sharedFile.isOneTime
      });
    } catch (error) {
      console.error('File share error:', error);
      res.status(500).json({ message: 'Failed to create shareable link' });
    }
  });

  // Serve shared files
  app.get('/f/:shortCode', async (req, res) => {
    try {
      const { shortCode } = req.params;
      const file = await storage.getFileByShortCode(shortCode);
      
      if (!file || !file.isShared) {
        return res.status(404).send('<h1>File not found</h1><p>This link is invalid or has expired.</p>');
      }
      
      if (file.isOneTime && file.isUsed) {
        return res.status(410).send('<h1>Link expired</h1><p>This one-time link has already been used.</p>');
      }
      
      // Mark one-time file as used
      if (file.isOneTime && !file.isUsed) {
        await storage.markFileAsUsed(shortCode);
      }
      
      // Serve the file
      if (fs.existsSync(file.path)) {
        res.setHeader('Content-Type', file.mimeType);
        res.setHeader('Content-Disposition', `inline; filename="${file.originalName}"`);
        const fileStream = fs.createReadStream(file.path);
        fileStream.pipe(res);
      } else {
        res.status(404).send('<h1>File not found</h1><p>The file no longer exists on the server.</p>');
      }
    } catch (error) {
      console.error('File serve error:', error);
      res.status(500).send('<h1>Server error</h1><p>An error occurred while serving the file.</p>');
    }
  });
  
  // Stripe subscription routes
  app.post("/api/create-subscription", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        const invoice = await stripe.invoices.retrieve(subscription.latest_invoice as string, {
          expand: ['payment_intent'],
        });
        
        const paymentIntent = (invoice as any).payment_intent;
        res.json({
          subscriptionId: subscription.id,
          clientSecret: paymentIntent?.client_secret,
        });
        return;
      }
      
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email || undefined,
          metadata: { userId: user.id },
        });
        customerId = customer.id;
      }
      
      // Create product and price separately
      const product = await stripe.products.create({
        name: 'Premium Subscription',
        description: 'Access to premium features: ad-free experience and 500MB file uploads',
      });

      const price = await stripe.prices.create({
        currency: 'usd',
        unit_amount: 500, // $5.00
        recurring: {
          interval: 'month',
        },
        product: product.id,
      });

      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{
          price: price.id,
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });
      
      await storage.updateUserStripeInfo(user.id, customerId, subscription.id);
      
      const invoice = subscription.latest_invoice as any;
      res.json({
        subscriptionId: subscription.id,
        clientSecret: invoice?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error('Subscription error:', error);
      res.status(400).json({ error: { message: error.message } });
    }
  });
  
  app.post("/api/subscription-success", requireAuth, async (req, res) => {
    try {
      const { subscriptionId } = req.body;
      const subscription = await stripe.subscriptions.retrieve(subscriptionId);
      
      if (subscription.status === 'active') {
        await storage.updateUserPremiumStatus(req.session.userId!, true);
        res.json({ success: true });
      } else {
        res.status(400).json({ message: "Subscription not active" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to confirm subscription" });
    }
  });

  // Handle short link redirects
  app.get("/s/:shortCode", async (req, res) => {
    try {
      const link = await storage.getLinkByShortCode(req.params.shortCode);
      
      if (!link) {
        return res.redirect(`/?error=not-found`);
      }

      if (link.isUsed) {
        return res.redirect(`/?error=expired&code=${req.params.shortCode}`);
      }

      // Mark link as used and redirect
      await storage.markLinkAsUsed(req.params.shortCode);
      res.redirect(link.originalUrl);
    } catch (error) {
      res.redirect(`/?error=server-error`);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
