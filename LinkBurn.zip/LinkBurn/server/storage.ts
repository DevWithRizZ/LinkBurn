import { type User, type InsertUser, type LoginUser, type Link, type InsertLink, type File, type InsertFile, type UpsertUser } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPremiumStatus(userId: string, isPremium: boolean): Promise<User | undefined>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User | undefined>;
  // Link operations
  createLink(link: InsertLink, userId?: string): Promise<Link>;
  getLinkByShortCode(shortCode: string): Promise<Link | undefined>;
  markLinkAsUsed(shortCode: string): Promise<Link | undefined>;
  // File operations
  createFile(file: InsertFile, userId: string): Promise<File>;
  getFilesByUser(userId: string): Promise<File[]>;
  getFile(id: string): Promise<File | undefined>;
  deleteFile(id: string): Promise<boolean>;
  // File sharing operations
  createFileShare(fileId: string, isOneTime: boolean): Promise<File | undefined>;
  getFileByShortCode(shortCode: string): Promise<File | undefined>;
  markFileAsUsed(shortCode: string): Promise<File | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private links: Map<string, Link>;
  private files: Map<string, File>;

  constructor() {
    this.users = new Map();
    this.links = new Map();
    this.files = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      email: insertUser.email || null,
      isPremium: false,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPremiumStatus(userId: string, isPremium: boolean): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      const updatedUser = { ...user, isPremium, updatedAt: new Date() };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      const updatedUser = { 
        ...user, 
        stripeCustomerId: customerId, 
        stripeSubscriptionId: subscriptionId,
        isPremium: true,
        updatedAt: new Date()
      };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async createLink(insertLink: InsertLink, userId?: string): Promise<Link> {
    const id = randomUUID();
    const shortCode = this.generateShortCode();
    const link: Link = {
      id,
      userId: userId || null,
      shortCode,
      originalUrl: insertLink.originalUrl,
      isUsed: false,
      createdAt: new Date(),
      usedAt: null,
    };
    this.links.set(shortCode, link);
    return link;
  }

  async getLinkByShortCode(shortCode: string): Promise<Link | undefined> {
    return this.links.get(shortCode);
  }

  async markLinkAsUsed(shortCode: string): Promise<Link | undefined> {
    const link = this.links.get(shortCode);
    if (link && !link.isUsed) {
      const updatedLink: Link = {
        ...link,
        isUsed: true,
        usedAt: new Date(),
      };
      this.links.set(shortCode, updatedLink);
      return updatedLink;
    }
    return link;
  }

  // File operations
  async createFile(insertFile: InsertFile, userId: string): Promise<File> {
    const id = randomUUID();
    const file: File = {
      ...insertFile,
      id,
      userId,
      shortCode: null,
      isShared: false,
      isOneTime: false,
      isUsed: false,
      usedAt: null,
      createdAt: new Date(),
    };
    this.files.set(id, file);
    return file;
  }

  async getFilesByUser(userId: string): Promise<File[]> {
    return Array.from(this.files.values()).filter(file => file.userId === userId);
  }

  async getFile(id: string): Promise<File | undefined> {
    return this.files.get(id);
  }

  async deleteFile(id: string): Promise<boolean> {
    return this.files.delete(id);
  }

  // File sharing operations
  async createFileShare(fileId: string, isOneTime: boolean): Promise<File | undefined> {
    const file = this.files.get(fileId);
    if (file) {
      const shortCode = this.generateShortCode();
      const updatedFile: File = {
        ...file,
        shortCode,
        isShared: true,
        isOneTime,
        isUsed: false,
        usedAt: null,
      };
      this.files.set(fileId, updatedFile);
      return updatedFile;
    }
    return undefined;
  }

  async getFileByShortCode(shortCode: string): Promise<File | undefined> {
    return Array.from(this.files.values()).find(file => file.shortCode === shortCode);
  }

  async markFileAsUsed(shortCode: string): Promise<File | undefined> {
    const file = Array.from(this.files.values()).find(f => f.shortCode === shortCode);
    if (file && !file.isUsed) {
      const updatedFile: File = {
        ...file,
        isUsed: true,
        usedAt: new Date(),
      };
      this.files.set(file.id, updatedFile);
      return updatedFile;
    }
    return file;
  }

  private generateShortCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    // Ensure uniqueness for both links and files
    if (this.links.has(result) || Array.from(this.files.values()).some(f => f.shortCode === result)) {
      return this.generateShortCode();
    }
    return result;
  }
}

export const storage = new MemStorage();
